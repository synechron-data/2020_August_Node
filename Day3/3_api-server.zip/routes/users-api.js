var express = require('express');
var router = express.Router();

const users_api_ctrl = require('../controllers/user-api-controller');

// Enabling CORS
router.use(function (req, res, next) {
    // update * to match the domain you will make the request from
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
})

router.get('/', users_api_ctrl.getUsers);

module.exports = router;
