// console.log(module);

// var fname = "Manish";
// module.exports = fname;

// var lname = "Sharma";
// module.exports = lname;

var fname = "Manish";
var lname = "Sharma";

// module.exports = { firstname: fname, lastname: lname };

// Named Exports
// module.exports.firstname = fname;
// module.exports.lastname = lname;

// module.exports.log = function (message) {
//     console.log("From Lib - ", message);
// }

exports.firstname = fname;
exports.lastname = lname;

exports.log = function (message) {
    console.log("From Lib - ", message);
}

// const Employee = (function () {
//     function Employee(name) {
//         this._name = name;
//     }

//     Employee.prototype.getName = function () {
//         return this._name;
//     }

//     Employee.prototype.setName = function (name) {
//         this._name = name;
//     }

//     return Employee;
// })();

class Employee {
    constructor(name) {
        this._name = name;
    }

    getName() {
        return this._name;
    }

    setName(name) {
        this._name = name;
    }
}

exports.Employee = Employee;