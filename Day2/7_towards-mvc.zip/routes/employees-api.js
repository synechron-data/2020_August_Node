const express = require('express');
const router = express.Router();

const empApiCtrl = require('../controllers/employee-api-controller');

router.get('/employees', empApiCtrl.getAllemployees);

router.get('/employees/:empid', empApiCtrl.getEmployee);

module.exports = router;