class SMS {
    send(message) {
        console.log("SMS Sent - ", message);
        // Twilio
    }
}

module.exports = SMS;