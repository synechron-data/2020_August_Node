$(document).ready(function () {
    $("#btnLoad").click(function () {
        $("#t_body").empty();

        $.ajax({
            url: 'api/users',
            type: 'GET',
            dataType: 'json',
            success: function (resData) {
                if (resData.data.length > 0) {
                    var tmpl = $.templates("#userRowTemplate");
                    var html = tmpl.render(resData.data);
                    $("#t_body").append(html);
                }
            },
            error: function (err) {
                console.error(err);
            }
        })
    })
})