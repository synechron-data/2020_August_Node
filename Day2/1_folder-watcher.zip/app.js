const chokidar = require('chokidar');
// console.log(chokidar);

const watcher = chokidar.watch('./my-folder');

watcher.on('add', (path) => { console.log(`File, ${path}, has been created....`) });
watcher.on('change', (path) => { console.log(`File, ${path}, has been changed....`) });
watcher.on('unlink', (path) => { console.log(`File, ${path}, has been deleted....`) });

console.log("Chokidar is watching.....");