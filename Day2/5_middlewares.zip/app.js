// Middleware is a subset of chained function called by the Express js app 
// before the user-defined handler is invoked. 

// Middleware functions have full access to the request and response objects 
// and can modify either of them.


var employees = [{ id: 1, name: "Manish" },
{ id: 2, name: "Abhijeet" },
{ id: 3, name: "Ram" },
{ id: 4, name: "Abhishek" },
{ id: 5, name: "Ramakant" }];

const express = require('express');
const logger = require('morgan');
const app = express();

app.set("view engine", "pug");

app.use(logger('dev'));

// app.use((req, res, next) => {
//     console.log("Request - Middleware 1");
//     next();
//     console.log("Response - Middleware 1");
// });

// app.use((req, res, next) => {
//     console.log("Request - Middleware 2");
//     next();
//     console.log("Response - Middleware 2");
// });

// app.use((req, res, next) => {
//     var stTime = new Date().getTime();
//     next();
//     var enTime = new Date().getTime();
//     var tTime = enTime - stTime;
//     console.log(`Total time ${tTime} ms`);
// });

app.get('/', (req, res) => {
    // console.log("Get Handler");
    res.render("index", { pageTitle: "Index View" });
});

app.get('/employees', (req, res) => {
    res.render("employees", { pageTitle: "Employees View", empList: employees });
});

app.listen(3000, () => {
    console.log("Express Server Started.....");
});