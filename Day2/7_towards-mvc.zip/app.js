const express = require('express');
const logger = require('morgan');
const favicon = require('express-favicon');

const indexRouter = require('./routes/index');
const employeesRouter = require('./routes/employees');
const employeesApiRouter = require('./routes/employees-api');

const app = express();

app.set("view engine", "pug");

app.use(logger('dev'));
app.use(favicon(__dirname + '/public/images/favicon.png'));

app.use('/', indexRouter);
app.use('/employees', employeesRouter);
app.use('/api', employeesApiRouter);

module.exports = app;