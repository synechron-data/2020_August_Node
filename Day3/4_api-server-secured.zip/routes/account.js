var express = require('express');
var router = express.Router();

const acc_ctrl = require('../controllers/account-controller');

module.exports = function (passport) {
    router.get('/', function (req, res, next) {
        res.redirect('account/login');
    });

    router.get('/login', acc_ctrl.login_get);

    router.post('/login', acc_ctrl.login_post(passport));

    router.post('/getToken', acc_ctrl.requestToken);

    return router;
};
