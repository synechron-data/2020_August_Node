const express = require('express');
const logger = require('morgan');
const favicon = require('express-favicon');
const path = require('path');

const indexRouter = require('./routes/index');
const employeesRouter = require('./routes/employees');

const app = express();

app.set("view engine", "pug");

app.use(express.static(path.join(__dirname, 'public')));
app.use('/css', express.static(path.join(__dirname, './node_modules/bootstrap/dist/css')));
app.use('/fonts', express.static(path.join(__dirname, './node_modules/bootstrap/dist/fonts')));
app.use('/scripts', express.static(path.join(__dirname, './node_modules/jquery/dist')));
app.use('/scripts', express.static(path.join(__dirname, './node_modules/bootstrap/dist/js')));

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(favicon(__dirname + '/public/images/favicon.png'));

app.use('/', indexRouter);
app.use('/employees', employeesRouter);

module.exports = app;